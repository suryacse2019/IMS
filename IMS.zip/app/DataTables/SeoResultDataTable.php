<?php

namespace App\DataTables;

use App\DataTables\BaseDataTable;
use App\Models\SeoTask;
use App\Models\SeoResult;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use Yajra\DataTables\Html\Button;
use Yajra\DataTables\Html\Column;

class SeoResultDataTable extends BaseDataTable
{

  

    public function __construct()
    {
        parent::__construct();
       
    }

    /**
     * Build DataTable class.
     *
     * @param mixed $query Results from query() method.
     * @return \Yajra\DataTables\DataTableAbstract
     */
    public function dataTable($query)
    {
        return datatables()
            ->eloquent($query)
            ->addColumn('action', function ($row) {
                $action = '<div class="task_view">

                <div class="dropdown">
                    <a class="task_view_more d-flex align-items-center justify-content-center dropdown-toggle" type="link"
                        id="dropdownMenuLink-' . $row->id . '" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="icon-options-vertical icons"></i>
                    </a>
                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenuLink-' . $row->id . '" tabindex="0">';

                $action .= '<a href="'.route('result-setting.show',$row->id).'" class="openRightModal dropdown-item"><i class="fa fa-eye mr-2"></i>' . __('app.view') . '</a>';

                $action .= '<a href="" class="dropdown-item"><i class="fa fa-download mr-2"></i>' . __('app.download') . '</a>';

                $action .= '<a href="'.route('result-setting.edit',$row->id).'" class="dropdown-item"><i class="fa fa-edit mr-2"></i>' . __('app.edit') . '</a>';
                $action .= '<a class="dropdown-item delete-table-row" href="javascript:;" data-seoresult-id="' . $row->id . '">
                            <i class="fa fa-trash mr-2"></i>
                            ' . trans('app.delete') . '
                        </a>';
                $action .= '</div>
                </div>
            </div>';

                return $action;
            })
            ->editColumn('title_name', function ($row) {
                if (!is_null($row->title_name)) {
                    return $row->title_name;
                }
                else {
                    return '--';
                }
            })
            ->editColumn('parent_id', function ($row) {
               if (!is_null($row->parent_id)) {
                    return $row->parent_id;
                }
                else {
                    return '--';
                }
            })
            ->editColumn('sort_order', function ($row) {
               if (!is_null($row->sort_order)) {
                    return $row->sort_order;
                }
                else {
                    return '--';
                }
            })
         
             ->editColumn('status', function ($row) {
                if ($row->status == '0') {
                    return 'Pending';
                }
                elseif ($row->status == '1') {
                    return 'Success';
                }
                
            })->rawColumns(['title_name', 'sort_order', 'status','action', 'parent_id'])
             ->removeColumn('currency_symbol')
             ->removeColumn('currency_code');
 
            
    }

    public function ajax()
    {
        return $this->dataTable($this->query())
            ->make(true);
    }

    /**
     * @return \Illuminate\Database\Query\Builder
     */
    public function query()
    {
        $request = $this->request();
        $model = SeoResult::select('seo_settings_result_title.title_name','seo_settings_result_title.id', 'seo_settings_result_title.parent_id', 'seo_settings_result_title.sort_order','seo_settings_result_title.status');
                

        if ($request->startDate !== null && $request->startDate != 'null' && $request->startDate != '') {
            $startDate = Carbon::createFromFormat($this->global->date_format, $request->startDate)->toDateString();
            $model = $model->where(DB::raw('DATE(seo_settings_result_title.`created_at`)'), '>=', $startDate);
        }

        if ($request->endDate !== null && $request->endDate != 'null' && $request->endDate != '') {
            $endDate = Carbon::createFromFormat($this->global->date_format, $request->endDate)->toDateString();
            $model = $model->where(DB::raw('DATE(seo_settings_result_title.`created_at`)'), '<=', $endDate);
        }

        if ($request->status != 'all' && !is_null($request->status)) {
            $model = $model->where('seo_settings_result_title.status', '=', $request->status);
        }

        return $model;
    }

    /**
     * Optional method if you want to use html builder.
     *
     * @return \Yajra\DataTables\Html\Builder
     */
    public function html()
    {
        return $this->builder()
            ->setTableId('seo_result-table')
            ->columns($this->getColumns())
            ->minifiedAjax()
            ->orderBy(1)
            ->destroy(true)
            ->responsive(true)
            ->serverSide(true)
            /* ->stateSave(true) */
            ->processing(true)
            ->language(__('app.datatable'))
            ->parameters([
                'initComplete' => 'function () {
                    window.LaravelDataTables["seo_result-table"].buttons().container()
                    .appendTo( "#table-actions")
                }',
                'fnDrawCallback' => 'function( oSettings ) {
                    $("body").tooltip({
                        selector: \'[data-toggle="tooltip"]\'
                    })
                }',
            ])
            ->buttons(Button::make(['extend' => 'excel', 'text' => '<i class="fa fa-file-export"></i> ' . trans('app.exportExcel')]));
    }

    /**
     * Get columns.
     *
     * @return array
     */
    protected function getColumns()
    {
        return [
            '#' => ['data' => 'DT_RowIndex', 'orderable' => false, 'searchable' => false, 'visible' => false],
            __('app.id') => ['data' => 'id', 'name' => 'id', 'title' => __('app.id')],
            __('modules.projects.seoresult')  => ['data' => 'title_name', 'name' => 'title_name', 'title' => __('modules.projects.seoresult')],
            __('modules.seoresult.parent_id')  => ['data' => 'parent_id', 'name' => 'parent_id', 'title' => __('modules.seoresult.parent_id')],
            __('modules.seoresult.sort_order') => ['data' => 'sort_order', 'name' => 'sort_order', 'title' => __('modules.seoresult.sort_order')],
            __('app.status') => ['data' => 'status', 'name' => 'status', 'title' => __('app.status')],
            Column::computed('action', __('app.action'))
                ->exportable(false)
                ->printable(false)
                ->orderable(false)
                ->searchable(false)
                ->addClass('text-right pr-20')
        ];
    }

    /**
     * Get filename for export.
     *
     * @return string
     */
    protected function filename()
    {
        return 'seo_result_title' . date('YmdHis');
    }

    public function pdf()
    {
        set_time_limit(0);

        if ('snappy' == config('datatables-buttons.pdf_generator', 'snappy')) {
            return $this->snappyPdf();
        }

        $pdf = app('dompdf.wrapper');
        $pdf->loadView('datatables::print', ['data' => $this->getDataForPrint()]);

        return $pdf->download($this->getFilename() . '.pdf');
    }

}
