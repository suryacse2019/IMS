<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\DataTables\WorkReportDataTable;
use App\Helper\Reply;
use App\Http\Requests\Admin\WorkReport\StoreRequest;
use App\Models\WorkReport;
use App\Http\Requests\Admin\WorkReport\UpdateRequest;

class WorkReportController extends AccountBaseController 
{

    public function __construct()
    {
        parent::__construct();
        $this->pageTitle =  __('app.workreport');
        
    }

    public function index(WorkReportDataTable $dataTable)
    {
        $this->fromDate = now($this->global->timezone)->startOfMonth();
        $this->toDate = now($this->global->timezone);
        return $dataTable->render('work-report.index',$this->data);
        
    }

    /**
     * XXXXXXXXXXX
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $this->pageTitle =  __('app.menu.work_report');
        if (request()->ajax()) {
            $html = view('work-report.ajax.create', $this->data)->render();
            return Reply::dataOnly(['status' => 'success', 'html' => $html, 'title' => $this->pageTitle]);
        }

        $this->view = 'work-report.ajax.create';

        return view('work-report.create', $this->data);

    }

    

    /**
     * @param StoreRequest $request
     * @return array
     * @throws \Froiden\RestAPI\Exceptions\RelatedResourceNotFoundException
     */
    public function store(StoreRequest $request)
    {
        $workreport = new WorkReport();
            $workreport->website_id = $request->website_id;
            $workreport->user_id = $request->user_id;
            $workreport->seo_task_id = $request->seo_task_id;
            $workreport->website_url = $request->website_url;
            $workreport->submission_websites_id = $request->submission_websites_id;
            $workreport->landing_url = $request->landing_url;
        $workreport->save();

        return Reply::successWithData(__('messages.employeeAdded'), ['redirectUrl' => route('work-report.index')]);
        
    
    }
    public function applyQuickAction(Request $request)
    {
        switch ($request->action_type) {
        case 'delete':
            $this->deleteRecords($request);
                return Reply::success(__('messages.deleteSuccess'));
        case 'change-status':
            $this->changeStatus($request);
                return Reply::success(__('messages.statusUpdatedSuccessfully'));
        default:
                return Reply::error(__('messages.selectAction'));
        }
    }

    /**
     * @param Request $request
     * @return array
     */
   
    public function edit($id)
    {
        $this->workreport = WorkReport::withoutGlobalScope('active')->findOrFail($id);
        $this->pageTitle =  __('app.menu.work-report');
        if (request()->ajax()) {
            $html = view('work-report.ajax.edit', $this->data)->render();

            return Reply::dataOnly(['status' => 'success', 'html' => $html, 'title' => $this->pageTitle]);
        }

        $this->view = 'work-report.ajax.edit';


        return view('work-report.create', $this->data);


    }

    /**
     * @param UpdateRequest $request
     * @param int $id
     * @return array
     * @throws \Froiden\RestAPI\Exceptions\RelatedResourceNotFoundException
     * @throws \Illuminate\Contracts\Filesystem\FileNotFoundException
     */
    public function update(UpdateRequest $request, $id)
    {

       
        $workreport = WorkReport::withoutGlobalScope('active')->findOrFail($id);
        // dd($user);
        $workreport->website_id = $request->website_id;
        $workreport->user_id = $request->user_id;
        $workreport->seo_task_id = $request->seo_task_id;
        $workreport->website_url = $request->website_url;
        $workreport->submission_websites_id = $request->submission_websites_id;
        $workreport->landing_url = $request->landing_url;
        $workreport->update();

        return Reply::successWithData(__('messages.updateSuccess'), ['redirectUrl' => route('work-report.index')]);
    }

    /**
     * Display the specified resource.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        


    }

      /**
     * @param int $id
     * @return array
     */
    public function destroy($id)
    {
        $user = WorkReport::findOrFail($id);
    
        WorkReport::where('id', $id)->delete();
        return Reply::success(__('messages.employeeDeleted'));

    }


}
