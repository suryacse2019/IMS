<?php

namespace App\Http\Controllers;

use App\Helper\Reply;
use App\DataTables\SeoResultDataTable;
use Illuminate\Http\Request;
use Carbon\Carbon;
use App\Http\Requests\ResultSetting\StoreResult;
use App\Http\Requests\ResultSetting\UpdateResult;
use App\Helper\Files;
use App\Models\User;
use App\Models\Project;
use App\Models\SeoTask;
use App\Models\SeoResult;
use App\Models\Currency;


class SeoResultController extends AccountBaseController
{
    public function __construct()
    {
        parent::__construct();
        $this->pageTitle = 'app.menu.seo';
    }

    /**
     * @return array|\Illuminate\Contracts\Foundation\Application|\Illuminate\Contracts\View\Factory|\Illuminate\Contracts\View\View|\Illuminate\Http\Response|mixed|void
     */
   
    public function create()
    {
        $this->seoresult = SeoResult::where('parent_id',0)->get();
        return view('seo-setting.create-result-modal',$this->data);

    }

    public function store(StoreResult $request){
   
        $result = new SeoResult();
        $result->title_name = $request->title_name;
        $result->parent_id = $request->parent_id;
        $result->sort_order = $request->sort_order;
        $result->status = $request->status;
        $result->save();

        $seo_result = SeoResult::get();
        return Reply::successWithData(__('messages.storeresult'), ['data' => $seo_result]);

        
    }

    

    public function edit($id)
    {
        $this->result = SeoResult::findOrFail($id);
        $this->seoresult = SeoResult::where('parent_id',0)->get();       
        return view('seo-setting.edit-result-modal', $this->data); 
       
    }

    public function update(UpdateResult $request, $id)
    {

        $result = SeoResult::findOrFail($id);
        $result->title_name = $request->title_name;
        $result->status = $request->status;

        $result->save();

        return Reply::success(__('messages.updateresult'));
    }

    public function show($id)
    {
        

        $this->pageTitle = __('modules.result-setting.resultdetail');

    }
    public function destroy($id){
        $result = SeoResult::findOrFail($id);
        SeoResult::destroy($id);
        return Reply::success(__('messages.deleteresult'));
    }
    
    
    




    

}
