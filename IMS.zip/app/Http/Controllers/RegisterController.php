<?php

namespace App\Http\Controllers;

use App\Helper\Reply;
use App\Http\Requests\User\AccountSetupRequest;
use App\Models\EmployeeDetails;
use App\Models\Permission;
use App\Models\Role;
use App\Models\Setting;
use App\Models\UniversalSearch;
use App\Models\Team;
use App\Models\Country;
use App\Models\User;
use App\Models\UserInvitation;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use App\Helper\Files;
use App\Models\EmployeeContacts;
use App\Models\EmployeeAddress;
use App\Models\EmployeeSkill;
use Carbon\Carbon;
use App\Http\Requests\Admin\Employee\UpdateRequest;
use App\Http\Requests\Admin\Employee\StoreRequest;
use App\Imports\EmployeeImport;
use Illuminate\Support\Facades\Bus;
use App\Jobs\ImportEmployeeJob;
use App\Http\Requests\Admin\Employee\ImportProcessRequest;
use Maatwebsite\Excel\Imports\HeadingRowFormatter;
use App\Http\Requests\User\InviteEmailRequest;



class RegisterController extends Controller
{

    public function invitation($code)
    {
        if (Auth::check()) {
            return redirect(route('dashboard'));
        }
        $this->lastEmployeeID = EmployeeDetails::max('id');
        $employee = new EmployeeDetails();
        if (!empty($employee->getCustomFieldGroupsWithFields())) {
            $this->fields = $employee->getCustomFieldGroupsWithFields()->fields;
        }
        $this->invite = UserInvitation::where('invitation_code', $code)
            ->where('status', 'active')
            ->firstOrFail();
        $this->maritalstatus = ['single','married','separated','divorced','widow'];
        $this->teams = Team::all();
        $this->countries = Country::all();
    
        return view('auth.invitation', $this->data);
    }



    //start Employee section

    public function store(StoreRequest $request)
    {
       // dd($request->all());

        DB::beginTransaction();
        try {

            $user = new User();
          // $data=$request->all();
            //dd($data);
            $user->name = $request->name;
            $user->email = $request->email;
            $user->password = bcrypt($request->password);
            $user->gender = $request->gender;
            $user->country_id = $request->country; 
            $user->mobile=$request->primary_mobile;

            if ($request->has('login')) {
                $user->login = $request->login;
            }

            if ($request->has('sendMail')) {
                $user->email_notifications = $request->sendMail == 'yes' ? 1 : 0;
            }

            if ($request->hasFile('image')) {
                Files::deleteFile($user->image, 'avatar');
                $user->image = Files::upload($request->image, 'avatar', 300);
            }

            // if ($request->has('telegram_user_id')) {
            //     $user->telegram_user_id = $request->telegram_user_id;
            // }

            $user->save();

            $emp_contacts_data=new EmployeeContacts();
            $emp_contacts_data->user_id = $user->id;
            $emp_contacts_data->name=$request->emergency_contact_person;
            $emp_contacts_data->mobile=$request->emergency_contact_no;
            $emp_contacts_data->relation=$request->relation;
            $emp_contacts_data->save(); 
            
           $employee_address = new EmployeeAddress();
           $employee_address->user_id = $user->id;
           $employee_address->address_type=1;
           $employee_address->street_address=$request->present_address;
           $employee_address->city=$request->city;
           $employee_address->state=$request->state;
           $employee_address->zipcode=$request->zipcode;
           $employee_address->country_id=$request->country;
           $employee_address->save(); 
    
          if($request->has('same_as_above')){  
      
            $permanent_address = $employee_address->replicate()->fill(['address_type' => 2]);
            $permanent_address->save();
            
        }else{       

           $emp_permanent_add = new EmployeeAddress();
           $emp_permanent_add->user_id = $user->id;
           $emp_permanent_add->address_type=2;
           $emp_permanent_add->street_address=$request->permanent_address;
           $emp_permanent_add->city=$request->permanent_city;
           $emp_permanent_add->state=$request->permanent_state;
           $emp_permanent_add->country_id=$request->country;
           $emp_permanent_add->zipcode=$request->permanent_zipcode;
           $emp_permanent_add->save(); 
            }

            if ($user->id) {
                $employee = new EmployeeDetails();
                $employee->user_id = $user->id;
                $this->employeeData($request, $employee);
                $employee->save();
                // To add custom fields data
                if ($request->get('custom_fields_data')) {
                    $employee->updateCustomFieldData($request->get('custom_fields_data'));
                }
            }

            // Commit Transaction
            DB::commit();

        } catch (\Swift_TransportException $e) {
            // Rollback Transaction
            DB::rollback();
            return Reply::error('Please configure SMTP details to add employee. Visit Settings -> notification setting to set smtp', 'smtp_error');
        } catch (\Exception $e) {
            // Rollback Transaction
            DB::rollback();
            return Reply::error('Some error occurred when inserting the data. Please try again or contact support');
        }

        return Reply::successWithData(__('messages.employeeAdded'), ['redirectUrl' => route('employees.index')]);
    }

   

    /**
     * Show the form for editing the specified resource.
     *
     * @param UpdateRequest $request
     * @param int $id
     * @return array
     * @throws \Froiden\RestAPI\Exceptions\RelatedResourceNotFoundException
     * @throws \Illuminate\Contracts\Filesystem\FileNotFoundException
     */
    public function update(UpdateRequest $request, $id)
    {

       // dd($id);
        $user = User::withoutGlobalScope('active')->findOrFail($id);
       // dd($user);
        $user->name = $request->name;
        $user->email = $request->email;
        $user->password = bcrypt($request->password);
        $user->gender = $request->gender;
        $user->country_id = $request->country; 
        $user->mobile=$request->primary_mobile;


        if ($request->password != '') {
            $user->password = bcrypt($request->password);
        }

     
        if($id != user()->id){
            $user->login = $request->login;
        }

    
        if ($request->hasFile('image')) {

            Files::deleteFile($user->image, 'avatar');
            $user->image = Files::upload($request->image, 'avatar', 300);
        }


        $user->save();

        $emp_contacts_data=EmployeeContacts::where('user_id', '=', $user->id)->first();
        if(!empty($emp_contacts_data))
        {
        $emp_contacts_data->user_id = $user->id;
        $emp_contacts_data->name=$request->emergency_contact_person;
        $emp_contacts_data->mobile=$request->emergency_contact_no;
        $emp_contacts_data->relation=$request->relation;
        $emp_contacts_data->save(); 
        }
        
        EmployeeAddress::where('user_id', $user->id)->delete();

       $employee_address = new EmployeeAddress();
       $employee_address->user_id = $user->id;
       $employee_address->address_type=1;
       $employee_address->street_address=$request->present_address;
       $employee_address->city=$request->city;
       $employee_address->state=$request->state;
       $employee_address->zipcode=$request->zipcode;
       $employee_address->country_id=$request->country;
       $employee_address->save(); 

      if($request->has('same_as_above')){  
  
        $permanent_address = $employee_address->replicate()->fill(['address_type' => 2]);
        $permanent_address->save();
        
    }else{       

       $emp_permanent_add = new EmployeeAddress();
       $emp_permanent_add->user_id = $user->id;
       $emp_permanent_add->address_type=2;
       $emp_permanent_add->street_address=$request->permanent_address;
       $emp_permanent_add->city=$request->permanent_city;
       $emp_permanent_add->state=$request->permanent_state;
       $emp_permanent_add->country_id=$request->country;
       $emp_permanent_add->zipcode=$request->permanent_zipcode;
       $emp_permanent_add->save(); 
        }



        $employee = EmployeeDetails::where('user_id', '=', $user->id)->first();

        if (empty($employee)) {
            //$employee = EmployeeDetails::where('user_id',$id);
            $employee->user_id = $user->id;
        }

        $this->employeeData($request, $employee);

        $employee->last_date = null;

        if ($request->last_date != '') {
            $employee->last_date = Carbon::createFromFormat($this->global->date_format, $request->last_date)->format('Y-m-d');
        }

        $employee->save();

    }

    /**
     * @param mixed $request
     * @param mixed $employee
     */
    public function employeeData($request, $employee): void
    {   
        /*
        $employee->employee_id = $request->employee_id;
        $employee->address = $request->address;
        $employee->hourly_rate = $request->hourly_rate;
        $employee->slack_username = $request->slack_username;
        $employee->department_id = $request->department;
        $employee->designation_id = $request->designation;
        */
        $employee->salary=$request->salary;
        $employee->pan_no=$request->pan_no;
        $employee->marital_status=$request->martialstatus;
        $employee->aadhar_no=$request->aadhar_no;
        $employee->bank_account_no=$request->bank_account_no;
        $employee->bank_ifsc=$request->bank_ifsc;
        $employee->bank_name=$request->bank_name;
        $employee->bank_branch=$request->branch;
        $employee->personal_email=$request->personal_email;
        $employee->primary_mobile=$request->primary_mobile;
        $employee->secondary_mobile=$request->secondry_mobile;
        $employee->father_name=$request->father_name;
        $employee->date_of_birth = $request->date_of_birth ? Carbon::createFromFormat($this->global->date_format, $request->date_of_birth)->format('Y-m-d') : null;

        $joiningdata=2022-05-23;
        $joiningyear=substr($joiningdata,2,2);
        $joiningmonth=substr($joiningdata,5,2);
        $empname=$request->name;
        $empname2=substr($empname,0,1);
       $max_id= DB::table('employee_details')->max('id');
       $max_id =$max_id+1;
        
       $employee->employee_id= 'IT'.$joiningyear.$joiningmonth.'0'. $max_id.$empname2;
       // dd($emp);
    }

/*

    public function employeeAddressData($request, $employee_address): void
    {   
        $employee_address->address_type='1';
        $employee_address->street_address=$request->present_address;
        $employee_address->city=$request->city;
        $employee_address->state=$request->state;
        $employee_address->zipcode=$request->zipcode;
     
        $employee_address->address_type='2';
        $employee_address->street_address=$request->permanent_address;
        $employee_address->city=$request->permanent_city;
        $employee_address->state=$request->permanent_state;
        $employee_address->zipcode=$request->zipcode;
     
     
    }

*/

    public function importMember()
    {
        $this->pageTitle = __('app.importExcel') . ' ' . __('app.employee');

        $addPermission = user()->permission('add_employees');
        abort_403(!in_array($addPermission, ['all', 'added']));


        if (request()->ajax()) {
            $html = view('employees.ajax.import', $this->data)->render();
            return Reply::dataOnly(['status' => 'success', 'html' => $html, 'title' => $this->pageTitle]);
        }

        $this->view = 'employees.ajax.import';

        return view('employees.create', $this->data);
    }

    public function importStore(ImportRequest $request)
    {
        $this->file = Files::upload($request->import_file, 'import-files', false, false, false);
        $excelData = Excel::toArray(new EmployeeImport, public_path('user-uploads/import-files/' . $this->file))[0];
        $this->hasHeading = $request->has('heading');
        $this->heading = array();

        $this->columns = EmployeeImport::$field;
        $this->importMatchedColumns = array();
        $this->matchedColumns = array();

        if ($this->hasHeading) {
            $this->heading = (new HeadingRowImport)->toArray(public_path('user-uploads/import-files/' . $this->file))[0][0];

            // Excel Format None for get Heading Row Without Format and after change back to config
            HeadingRowFormatter::default('none');
            $this->fileHeading = (new HeadingRowImport)->toArray(public_path('user-uploads/import-files/' . $this->file))[0][0];
            HeadingRowFormatter::default(config('excel.imports.heading_row.formatter'));

            array_shift($excelData);
            $this->matchedColumns = collect($this->columns)->whereIn('id', $this->heading)->pluck('id');
            $importMatchedColumns = array();

            foreach ($this->matchedColumns as $matchedColumn) {
                $importMatchedColumns[$matchedColumn] = 1;
            }

            $this->importMatchedColumns = $importMatchedColumns;
        }

        $this->importSample = array_slice($excelData, 0, 5);

        $view = view('employees.ajax.import_progress', $this->data)->render();

        return Reply::successWithData(__('messages.importUploadSuccess'), ['view' => $view]);
    }

    public function importProcess(ImportProcessRequest $request)
    {
        // clear previous import
        Artisan::call('queue:clear database --queue=import_employee');
        Artisan::call('queue:flush');
        // Get index of an array not null value with key
        $columns = array_filter($request->columns, function ($value) {
            return $value !== null;
        });

        $excelData = Excel::toArray(new EmployeeImport, public_path('user-uploads/import-files/' . $request->file))[0];

        if ($request->has_heading) {
            array_shift($excelData);
        }

        $jobs = [];

        foreach ($excelData as $row) {

            $jobs[] = (new ImportEmployeeJob($row, $columns));
        }

        $batch = Bus::batch($jobs)->onConnection('database')->onQueue('import_employee')->name('import_employee')->dispatch();

        Files::deleteFile($request->file, 'import-files');

        return Reply::successWithData(__('messages.importProcessStart'), ['batch' => $batch]);
    }

    
    

}
