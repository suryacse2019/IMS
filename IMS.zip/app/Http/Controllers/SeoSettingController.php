<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Project;
use App\DataTables\SeoTaskDataTable;
use App\Models\Currency;
use App\Helper\Reply;
use App\Models\SeoTask;
use App\Models\SeoResult;
use App\Models\Website;
use Froiden\Envato\Traits\AppBoot;

class SeoSettingController extends AccountBaseController
{
    
    
    public function __construct()
    {
        parent::__construct();
        $this->pageTitle = 'app.menu.seo';
        $this->activeSettingMenu = 'seo_setting';
        
    }
    public function isActive($option)
    {
        return $option === $this->active;
    }

    /**
     * @return array|\Illuminate\Contracts\Foundation\Application|\Illuminate\Contracts\View\Factory|\Illuminate\Contracts\View\View|\Illuminate\Http\Response|mixed|void
     */
    public function index()
    {
        $this->seotask = SeoTask::all();
        $this->web_setting = Website::get();
        // $this->seoresult = SeoResult::all();
        $seoresult = SeoResult::OrderBy('sort_order','asc')->where('parent_id', 0)->get();

        if(!empty($seoresult)){
            $seoresult = $seoresult->map(function($result){
                $result->child = SeoResult::where('parent_id', $result->id)->get();
                return $result;
            });
        }

        $this->seoresult = $seoresult;
        

        $this->view = 'seo-setting.ajax.seowebsite';

        $tab = request('tab');

        switch ($tab) {
        case 'task':
            $this->view = 'seo-setting.ajax.seotask';
                break;
        case 'result':
            $this->view = 'seo-setting.ajax.seoresult';
                break;
                default:
            $this->view = 'seo-setting.ajax.seowebsite';
                break;
        }

        ($tab == '') ? $this->activeTab = 'website' : $this->activeTab = $tab;

        if (request()->ajax()) {
            $html = view($this->view, $this->data)->render();
            return Reply::dataOnly(['status' => 'success', 'html' => $html, 'title' => $this->pageTitle, 'activeTab' => $this->activeTab]);
        }

        return view('seo-setting.index', $this->data);

    }

   

}
