<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\DataTables\WorkReportDataTable;
use App\Helper\Reply;
use Carbon\Carbon;
use App\Models\Website;
use App\Models\SeoResult;
use App\Models\SeoWebsiteResult;
use App\Http\Requests\Admin\WorkReport\StoreRequest;
use DB;

use App\Http\Requests\Admin\WorkReport\UpdateRequest;

class SeoWebsiteResultController extends AccountBaseController 
{

    public function __construct()
    {
        parent::__construct();
        $this->pageTitle =  __('app.menu.seo_result');
        
    }

    public function index()
    {
        $this->web_setting = Website::get();
        $seoresult = SeoResult::OrderBy('sort_order','asc')->where('parent_id', 0)->get();
        $now = Carbon::now();

        $this->year = $now->format('Y');

        $this->month = $now->format('m');

        if(!empty($seoresult)){
            $seoresult = $seoresult->map(function($result){
                $result->child = SeoResult::where('parent_id', $result->id)->get();
                return $result;
            });
        }

        $this->seoresult = $seoresult;
        

        return view('Seo-Website-Result.index',$this->data);
        
    }

    /**
     * XXXXXXXXXXX
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        

    }

    

    /**
     * @param StoreRequest $request
     * @return array
     * @throws \Froiden\RestAPI\Exceptions\RelatedResourceNotFoundException
     */
    public function store(Request $request)
    {
       
        $web_id=$request->seo_websites;
        $title=$request->title_id;
        foreach($web_id as $key=>$value){
            $title_id=$title[$key];
            //dd($title_id);
            SeoWebsiteResult::updateOrCreate([
                'id'=>$title_id,
            ],[
                'result_value'=>$value,
                'result_title_id'=>$title_id,
                'website_id'=>$request->website_name,
                'month' =>  $request->month,
                'year'  =>  $request->year,
            ]);
        }

        return Reply::successWithData(__('messages.updateSuccess'), ['redirectUrl' => route('seo-result.index')]);


        
    
    }
   

    /**
     * @param Request $request
     * @return array
     */
   
    public function edit($id)
    {
        
    }

    /**
     * @param UpdateRequest $request
     * @param int $id
     * @return array
     * @throws \Froiden\RestAPI\Exceptions\RelatedResourceNotFoundException
     * @throws \Illuminate\Contracts\Filesystem\FileNotFoundException
     */
    public function update(UpdateRequest $request, $id)
    {

       
    }

    /**
     * Display the specified resource.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        


    }

      /**
     * @param int $id
     * @return array
     */
    public function destroy($id)
    {
      

    }


    public function getState(Request $request)
    {
        //   $data = SeoWebsiteResult::select('result_value','result_title_id')->where("website_id",$request->website_id)->get();

        $web_data= DB::table('seo_website_result')
            ->join('seo_settings_result_title', 'seo_website_result.result_title_id', '=', 'seo_settings_result_title.id')
            ->select('seo_website_result.result_value','seo_settings_result_title.title_name', 'seo_settings_result_title.id', 'seo_settings_result_title.parent_id','seo_website_result.result_title_id')
            ->where(["seo_website_result.website_id" => $request->website_id,
                    "seo_website_result.month" => $request->month,
                    "seo_website_result.year" => $request->year])
            ->get();
        
            
       // dd($data);
        $seoresult= SeoResult::OrderBy('sort_order','asc')->where('parent_id', 0)->get();
     
        if(!empty($seoresult)){
            $seoresult = $seoresult->map(function($result){
                $result->child = SeoResult::where('parent_id', $result->id)->get();
                return $result;
            });
        }

        $data['web_data'] = $web_data;
        $data['seoresult'] = $seoresult;

        return response()->json($data);
    }

  

}
