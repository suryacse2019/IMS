<?php

namespace App\Http\Controllers;

use App\Helper\Reply;
use App\Models\PaymentMethod;
use App\Http\Requests\PaymentMethod\PaymentMethodType;
use Illuminate\Http\Request;

class PaymentMethodController extends AccountBaseController
{

    public function __construct()
    {
        parent::__construct();
        $this->pageTitle = 'app.menu.paymentMethod';
        $this->activeSettingMenu = 'payment_method_settings';
        $this->middleware(function ($request, $next) {
            abort_403(!(user()->permission('manage_payment_setting') == 'all'));
            return $next($request);
        });
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {   

         $this->methodTypes = PaymentMethod::all();
        return view('payment-method-settings.index', $this->data);


    }



    public function create()
    {   
        $this->methodTypes = PaymentMethod::all();
        return view('payment-method-settings.create-payment-method',$this->data);
    }

    /**
     * @param UpdateGatewayCredentials $request
     * @param int $id
     * @return array
     * @throws \Froiden\RestAPI\Exceptions\RelatedResourceNotFoundException
     */
    public function store(PaymentMethodType $request)
    {  
       
        $methodTypes = new PaymentMethod();
        $methodTypes->method_name = $request->method_name;
        $methodTypes->parent_id = $request->parent_id;
        $methodTypes->method_desc = $request->method_desc;
        
        $methodTypes->save();
       
       $methodTypes = PaymentMethod::get();
      
        return Reply::successWithData(__('messages.methodTypeAdded'),[ 'page_reload' => $request->page_reload]);
    }



     public function edit($id)
    {   

         $this->methodTypes = PaymentMethod::all();
        $this->methodType = PaymentMethod::find($id);
        return view('payment-method-settings.edit-payment-method', $this->data);
    }

      public function update(Request $request, $id)
    {
       
 
        $methodTypes = PaymentMethod::findOrFail($id);
        $methodTypes->method_name = $request->method_name;
        $methodTypes->parent_id = $request->parent_id;
        $methodTypes->method_desc = $request->method_desc;
        $methodTypes->status = $request->status;
        
        
        $methodTypes->save();

        return Reply::successWithData(__('messages.methodUpdate'),[ 'page_reload' => $request->page_reload]);
    }

      public function destroy($id)
    {
        PaymentMethod::destroy($id);
        return Reply::success(__('messages.methodDeleteSuccess'));
    }


}
