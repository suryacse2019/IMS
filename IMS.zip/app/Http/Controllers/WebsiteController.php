<?php

namespace App\Http\Controllers;

use App\Helper\Reply;
use Illuminate\Http\Request;
use Carbon\Carbon;
use App\Http\Requests\WebsiteSetting\UpdateWebsite;
use App\Http\Requests\WebsiteSetting\StoreWebsite;
use App\Models\Currency;
use App\Models\Website;
use App\Models\Country;



class WebsiteController extends AccountBaseController
{
    public function __construct()
    {
        parent::__construct();
        $this->pageTitle = 'app.menu.website';
        $this->activeSettingMenu = 'Website_settings';
    }

    /**
     * @return array|\Illuminate\Contracts\Foundation\Application|\Illuminate\Contracts\View\Factory|\Illuminate\Contracts\View\View|\Illuminate\Http\Response|mixed|void
     */
   
    public function index(){
        $this->web_setting = Website::get();
        return view('website-setting.index',$this->data);

    } public function create(){

        return view('website-setting.create');

    }
    public function store(StoreWebsite $request){

        $web_setting = new Website();
        $web_setting->website_name = $request->website_name;
        $web_setting->website_url = $request->website_url;
        $web_setting->countries_id = $request->countries_id;    
        $web_setting->start_date  = $request->start_date ? Carbon::createFromFormat($this->global->date_format, $request->start_date)->format('Y-m-d') : null;

        $web_setting->save();

        $website_setting = Website::get();
        return Reply::successWithData(__('messages.storewebsite'), ['data' => $website_setting]);

        
    }

    public function edit($id){
        $this->web_setting = Website::findOrFail($id);

        return view('website-setting.edit', $this->data);
    }

   

    public function update(StoreWebsite $request, $id){
        $web_setting = Website::findOrFail($id);
        $web_setting->website_name = $request->website_name;
        $web_setting->website_url = $request->website_url;
        $web_setting->countries_id = $request->countries_id;
        $web_setting->start_date  = $request->start_date ? Carbon::createFromFormat($this->global->date_format, $request->start_date)->format('Y-m-d') : null;


        $web_setting->save();

       
        

        return Reply::success(__('messages.updatewebsite'));
        
    }
    public function destroy($id){
        $web_setting = Website::findOrFail($id);
        Website::destroy($id);
        return Reply::success(__('messages.deletewebsite'));
    }
    




    

}
