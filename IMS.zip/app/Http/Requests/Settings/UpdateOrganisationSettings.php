<?php

namespace App\Http\Requests\Settings;

use App\Http\Requests\CoreRequest;
use Illuminate\Foundation\Http\FormRequest;

class UpdateOrganisationSettings extends CoreRequest
{

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {

        $rules = [];

        if ($this->company_method == 'compnyinfo' ) {
            $rules = [
            'company_full_name'=>'required',
            'company_brand_name' => 'required',
            'company_email' => 'required|email',
            'company_website' => 'nullable|url|max:50',
            'company_cin' => 'required',
            'company_regno'=>'required',
            'company_pan'=>'required',
            'company_tan'=>'required',
            'company_gst'=>'required',
            'company_iec'=>'required',
            ];

        } 
        
        // if ($this->company_method == 'dininfo' ) {

        //     $rules = [
        //         'din_id_1'=>'required',
        //         'din_name_1'=>'required',
        //         'din_joining_1'=>'required',
        //         'din_share_1'=>'required',
        //         'din_id_2'=>'required',
        //         'din_name_2'=>'required',
        //         'din_joining_2'=>'required',
        //         'din_share_2'=>'required',
        //         'din_id_3'=>'required',
        //         'din_name_3'=>'required',
        //         'din_joining_3'=>'required',
        //         'din_share_3'=>'required',
        //         ];

        // }
        if ($this->contact_method == 'contactinfo' ) {

            $rules = [
        
                'contact_phone_1'=>'required',
                'contact_phone_2'=>'required',
                'contact_street_address'=>'required',
                'contact_city'=>'required',
                'contact_state'=>'required',
                'contact_zipcode'=>'required',
                'contact_countryId'=>'required'
            ];
        }
        if ($this->company_method == 'social' ) {

                $rules = [
                'facebook'=>'required|url',
                'instagram'=>'required|url',
                'linkedin'=>'required|url',
                'twitter'=>'required|url',
                'whatsapp'=>'required|url',
                'google_map'=>'required|url',
            ];
        }

        if($this->has('google_recaptcha') && $this->google_recaptcha == 'on')
        {
            $rules['google_recaptcha_key'] = 'required';
            $rules['google_recaptcha_secret'] = 'required';
        }

        return $rules;
    }

}

