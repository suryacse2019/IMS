<?php

namespace App\Http\Requests\BankAccount;

use App\Http\Requests\CoreRequest;

class bankAccountType extends CoreRequest
{

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'bank_name'=>'required',
            'account_no' => 'required|unique:company_bank',
            'ifsc_code' => 'required',
            'branch_address'=>'required',
        ];
    }

}
