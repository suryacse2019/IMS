<?php

namespace App\Http\Requests\TaskSetting;

use App\Http\Requests\CoreRequest;

class UpdateTask extends CoreRequest
{

    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $rules = [
            'task_priority' => 'required|numeric',
            'seo_task_title' => 'required',
            'no_of_submission'=>'required|numeric',
            'task_frequency'=>'required|numeric',
           
        ];



        return $rules;
    }

    public function messages()
    {
        return $messges = [
        ];
    }

}
